Autores: Matheus Emmanoel Santana, Victor Ezequiel Queiroz Alves

P0 - A1 e A2 foram realizadas.